# InstaBoost static starter

This is a static HTML storefront preview that can be deployed on Netlify.

## Deploy with Netlify
1. Upload `index.html` to the root of your GitHub repository (or upload this ZIP in Netlify's manual deploy flow).
2. For a GitHub-connected Netlify site, choose **Import an existing project** and select this repository.
3. Build command: leave blank.
4. Publish directory: `.`

## Important
The order form is preview-only. It does not save orders or process payments. Do not use it to collect real UPI payments or UTRs until a secure backend and admin authentication have been configured.
